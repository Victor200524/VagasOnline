

export default function TelaTabelaVagas(){
    return(
        <div>
            <h1>Tela de Tabela de Vagas</h1>
        </div>
    );
}