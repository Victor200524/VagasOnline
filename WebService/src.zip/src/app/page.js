import TelaTabelaVagas from "@/components/TelaTabelaVagas";

export default function Home() {
  return (
    <div>
      <TelaTabelaVagas />
    </div>
  );
}
