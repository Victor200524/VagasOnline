package victor.trabalhovagasonline.vagasonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VagasonlineApplication {

    public static void main(String[] args) {
        SpringApplication.run(VagasonlineApplication.class, args);
    }

}
